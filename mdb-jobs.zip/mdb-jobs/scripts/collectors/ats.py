"""
ats.py — collectors for hosted Applicant Tracking Systems (ATS).

THE KEY INSIGHT
---------------
Most institutions don't build their own careers site. They rent one from an
ATS vendor: SmartRecruiters, Greenhouse, Workday, SuccessFactors, Oracle
Recruiting Cloud, Taleo. Each vendor serves every one of its clients from the
SAME API, with only a company slug changing.

So you don't write 40 scrapers for 40 organisations. You write ONE collector
per vendor, and add organisations as config lines. This is how you keep a
project like yours maintainable by one person.

HOW TO FIND AN ORGANISATION'S VENDOR AND SLUG
---------------------------------------------
1. Open the organisation's careers page.
2. Look at the URL. `jobs.smartrecruiters.com/EIB` → SmartRecruiters, slug
   "EIB". `boards.greenhouse.io/xyz` → Greenhouse, slug "xyz".
3. If the URL doesn't tell you: open the browser's developer tools (F12),
   go to the Network tab, filter to "Fetch/XHR", and reload the page. The
   requests you see are the API the page itself is calling. Copy that URL.

That third step is the single most useful scraping skill there is. The page
you see is almost always a thin wrapper around a JSON API you can call
directly.
"""

from __future__ import annotations

from .base import Collector, Job, to_iso_date


class SmartRecruitersCollector(Collector):
    """Public postings API: api.smartrecruiters.com/v1/companies/{slug}/postings

    No API key needed for public postings. Returns 100 per page.
    """

    name = "smartrecruiters"
    BASE = "https://api.smartrecruiters.com/v1/companies/{slug}/postings"

    def fetch(self) -> list[Job]:
        jobs: list[Job] = []

        # config looks like: companies: [{slug: EIB, organisation: "European Investment Bank"}]
        for company in self.config.get("companies", []):
            slug = company["slug"]
            org_name = company.get("organisation", slug)
            offset = 0

            while True:
                data = self.get_json(
                    self.BASE.format(slug=slug),
                    params={"limit": 100, "offset": offset},
                )
                postings = data.get("content", [])
                if not postings:
                    break

                for p in postings:
                    jobs.append(self._to_job(p, slug, org_name))

                offset += len(postings)
                if offset >= data.get("totalFound", 0):
                    break

        return jobs

    def _to_job(self, p: dict, slug: str, org_name: str) -> Job:
        location = p.get("location") or {}
        experience = (p.get("experienceLevel") or {}).get("id")

        return Job(
            source=f"{self.name}:{slug}",
            external_id=str(p.get("id") or p.get("uuid")),
            # The public apply page follows a predictable pattern.
            url=f"https://jobs.smartrecruiters.com/{slug}/{p.get('id')}",
            title=(p.get("name") or "").strip(),
            organisation=org_name,
            city=location.get("city"),
            country=location.get("country"),
            date_posted=to_iso_date(p.get("releasedDate")),
            # SmartRecruiters rarely exposes a deadline publicly.
            deadline=None,
            grade=experience,
            contract_type=(p.get("typeOfEmployment") or {}).get("label"),
            raw=p,
        )


class GreenhouseCollector(Collector):
    """Public board API: boards-api.greenhouse.io/v1/boards/{slug}/jobs"""

    name = "greenhouse"
    BASE = "https://boards-api.greenhouse.io/v1/boards/{slug}/jobs"

    def fetch(self) -> list[Job]:
        jobs: list[Job] = []

        for company in self.config.get("companies", []):
            slug = company["slug"]
            org_name = company.get("organisation", slug)

            data = self.get_json(self.BASE.format(slug=slug))

            for p in data.get("jobs", []):
                location_name = (p.get("location") or {}).get("name") or ""
                # Greenhouse gives one free-text location string like
                # "Washington, DC, United States". Split on the last comma.
                city, _, country = location_name.rpartition(",")

                jobs.append(
                    Job(
                        source=f"{self.name}:{slug}",
                        external_id=str(p.get("id")),
                        url=p.get("absolute_url", ""),
                        title=(p.get("title") or "").strip(),
                        organisation=org_name,
                        city=city.strip() or None,
                        country=country.strip() or location_name or None,
                        date_posted=to_iso_date(p.get("updated_at")),
                        deadline=None,
                        raw=p,
                    )
                )

        return jobs
