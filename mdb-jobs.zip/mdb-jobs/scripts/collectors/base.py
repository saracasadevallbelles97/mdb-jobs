"""
base.py — the shared "shape" that every collector must produce.

WHY THIS FILE EXISTS
--------------------
Each job board (ReliefWeb, SmartRecruiters, Greenhouse, a hand-written HTML
scraper...) returns data in a completely different format. If the rest of the
program had to know about all those formats, every new source would mean
changing code everywhere.

So we do the standard trick: every collector converts its messy source data
into ONE agreed dictionary shape, defined below. The rest of the pipeline
(normalise, dedupe, build site, digest) only ever sees that shape.

This is called an "adapter" pattern. It is the single most useful idea in a
scraping project.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, date
from typing import Optional

import requests

# A polite, identifiable user agent. Some sites block unknown clients, and
# being honest about who you are is both practical and good manners.
USER_AGENT = "mdb-jobs-tracker/0.1 (+https://github.com/YOUR-USERNAME/mdb-jobs)"

# How long to wait for a server before giving up, in seconds.
TIMEOUT = 30


@dataclass
class Job:
    """One job posting, in our own vocabulary.

    A dataclass is just a class where Python writes the boilerplate for you.
    Think of it as a labelled box: it holds fields and knows how to turn
    itself into a plain dictionary (via asdict).
    """

    # --- identity -----------------------------------------------------
    source: str            # which collector produced this, e.g. "reliefweb"
    external_id: str       # the id the source itself uses
    url: str               # link a human can open and apply through

    # --- the actual content -------------------------------------------
    title: str
    organisation: str      # "World Bank", "UNDP", "EBRD"...

    # --- the things you said you want to filter on ---------------------
    city: Optional[str] = None
    country: Optional[str] = None
    date_posted: Optional[str] = None     # ISO date string "2026-09-17"
    deadline: Optional[str] = None        # ISO date string
    grade: Optional[str] = None           # raw grade text, e.g. "P-4", "GF"
    seniority: Optional[str] = None       # our own tidy bucket, filled later
    contract_type: Optional[str] = None   # "Staff", "Consultancy", "Internship"

    # --- bookkeeping ---------------------------------------------------
    first_seen: Optional[str] = None      # when WE first saw it
    last_seen: Optional[str] = None       # when we last saw it still listed
    raw: dict = field(default_factory=dict)  # keep the original, for debugging

    @property
    def id(self) -> str:
        """A stable, unique fingerprint for this job.

        We hash source + external_id so the same posting always gets the same
        id on every run. That is what lets us tell "new this week" apart from
        "was already there last week".
        """
        return hashlib.sha1(
            f"{self.source}:{self.external_id}".encode("utf-8")
        ).hexdigest()[:16]

    def to_dict(self) -> dict:
        d = asdict(self)
        d["id"] = self.id
        return d


class Collector:
    """Base class. Every source subclasses this and implements fetch()."""

    name = "base"

    def __init__(self, config: dict | None = None):
        self.config = config or {}
        # A Session reuses the network connection between requests, which is
        # both faster and gentler on the server than opening a new one each time.
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT})

    def fetch(self) -> list[Job]:
        raise NotImplementedError("Each collector must implement fetch()")

    # --- small helpers every collector tends to need ---------------------

    def get_json(self, url: str, **kwargs) -> dict:
        r = self.session.get(url, timeout=TIMEOUT, **kwargs)
        r.raise_for_status()   # turns a 404/500 into a loud Python error
        return r.json()

    def post_json(self, url: str, payload: dict, **kwargs) -> dict:
        r = self.session.post(url, json=payload, timeout=TIMEOUT, **kwargs)
        r.raise_for_status()
        return r.json()


# ----------------------------------------------------------------------
# Date handling. Job boards return dates in maddening variety. We funnel
# everything through this one function so the rest of the code can assume
# "a date is always the string YYYY-MM-DD, or None".
# ----------------------------------------------------------------------

_DATE_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%dT%H:%M:%S%z",
    "%Y-%m-%dT%H:%M:%S.%f%z",
    "%d/%m/%Y",
    "%m/%d/%Y",
    "%d %b %Y",
    "%d %B %Y",
    "%b %d, %Y",
    "%B %d, %Y",
]


def to_iso_date(value) -> Optional[str]:
    """Turn almost anything date-ish into 'YYYY-MM-DD'. Return None if hopeless."""
    if value is None or value == "":
        return None
    if isinstance(value, (datetime, date)):
        return value.strftime("%Y-%m-%d")

    text = str(value).strip()

    # Some APIs hand back milliseconds since 1970. Detect a long run of digits.
    if re.fullmatch(r"\d{10}|\d{13}", text):
        seconds = int(text) / (1000 if len(text) == 13 else 1)
        return datetime.utcfromtimestamp(seconds).strftime("%Y-%m-%d")

    # Trim a trailing 'Z' (means UTC) which older Python can't parse.
    cleaned = text.replace("Z", "+0000")

    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(cleaned, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue

    # Last resort: pull a bare YYYY-MM-DD out of a longer string.
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", text)
    if m:
        return m.group(0)

    return None
