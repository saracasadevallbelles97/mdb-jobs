"""
reliefweb.py — the single best starting source.

WHY START HERE
--------------
ReliefWeb (run by UN OCHA) aggregates job postings from hundreds of UN
agencies, IFIs and international NGOs, and publishes them through a FREE,
PUBLIC, DOCUMENTED API that returns clean JSON. No HTML parsing, no CSS
selectors that break when someone redesigns a page.

Rule of thumb for this whole project: **an API beats a scraper every single
time.** Only write an HTML scraper when no API exists.

IMPORTANT — VERIFY BEFORE YOU TRUST
-----------------------------------
API URLs, required parameters and rate limits change. Before your first run,
open the current docs and check the base URL, whether an `appname` or API key
is required, and the field names:

    https://apidoc.reliefweb.int/

If a field below no longer exists, the code will simply return None for it
rather than crashing — but you should still check.
"""

from __future__ import annotations

from .base import Collector, Job, to_iso_date

API_URL = "https://api.reliefweb.int/v1/jobs"

# Fields we ask the API to send back. Asking for only what you need keeps the
# response small and fast.
FIELDS = [
    "id",
    "title",
    "url_alias",
    "date.created",
    "date.closing",
    "source.name",
    "source.shortname",
    "country.name",
    "city.name",
    "career_categories.name",
    "experience.name",
    "type.name",
    "theme.name",
]


class ReliefWebCollector(Collector):
    name = "reliefweb"

    def fetch(self) -> list[Job]:
        # `appname` identifies your application to ReliefWeb. Set it in
        # config/sources.yaml to something like your GitHub repo URL.
        appname = self.config.get("appname", "mdb-jobs-tracker")

        # Which organisations to keep. ReliefWeb carries a LOT of NGO postings;
        # this filter is what makes the feed about development banks and
        # international organisations specifically.
        org_filter = self.config.get("organisations", [])

        limit = int(self.config.get("limit", 200))     # per page
        max_pages = int(self.config.get("max_pages", 5))

        jobs: list[Job] = []
        offset = 0

        for _ in range(max_pages):
            payload = {
                "appname": appname,
                "limit": limit,
                "offset": offset,
                "sort": ["date.created:desc"],
                "fields": {"include": FIELDS},
                "preset": "latest",
            }

            # The API's filter syntax: match any of these source names.
            if org_filter:
                payload["filter"] = {
                    "field": "source.name",
                    "value": org_filter,
                    "operator": "OR",
                }

            data = self.post_json(API_URL, payload)
            items = data.get("data", [])
            if not items:
                break

            for item in items:
                jobs.append(self._to_job(item))

            offset += limit
            # Stop early if we've reached the end of the result set.
            if offset >= data.get("totalCount", 0):
                break

        return jobs

    def _to_job(self, item: dict) -> Job:
        """Translate one ReliefWeb record into our Job shape."""
        f = item.get("fields", {})

        # Many ReliefWeb fields are LISTS of objects even when there's only
        # one value, so we write a tiny helper instead of repeating ourselves.
        def first_name(key: str):
            values = f.get(key) or []
            if isinstance(values, list) and values:
                return values[0].get("name")
            return None

        return Job(
            source=self.name,
            external_id=str(item.get("id") or f.get("id")),
            url=f.get("url_alias") or f"https://reliefweb.int/node/{item.get('id')}",
            title=f.get("title", "").strip(),
            organisation=first_name("source") or "Unknown",
            city=first_name("city"),
            country=first_name("country"),
            date_posted=to_iso_date((f.get("date") or {}).get("created")),
            deadline=to_iso_date((f.get("date") or {}).get("closing")),
            contract_type=first_name("type"),
            # ReliefWeb's "experience" field is things like "5-9 years" — a
            # useful hint for our seniority classifier later on.
            grade=first_name("experience"),
            raw=f,
        )
