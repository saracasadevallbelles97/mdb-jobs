"""
Registry of available collectors.

The dictionary below maps the `type:` value in config/sources.yaml to the
class that handles it. To add a new kind of source: write the class, import
it here, add one line to the dict. Nothing else in the project changes.

Every collector in this project reads a public API. None of them parse HTML.
That is a deliberate constraint, not a limitation — an API returns the data
the site's own page is built from, so it is both cleaner and more stable than
reading the rendered page.
"""

from .base import Collector, Job, to_iso_date
from .reliefweb import ReliefWebCollector
from .ats import SmartRecruitersCollector, GreenhouseCollector

COLLECTORS: dict[str, type[Collector]] = {
    "reliefweb": ReliefWebCollector,
    "smartrecruiters": SmartRecruitersCollector,
    "greenhouse": GreenhouseCollector,
}

__all__ = ["COLLECTORS", "Collector", "Job", "to_iso_date"]
