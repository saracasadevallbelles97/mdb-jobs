"""
digest.py — build the weekly newsletter draft.

    python scripts/digest.py

Writes digests/YYYY-MM-DD.md containing only the jobs that appeared for the
first time in the last 7 days, grouped by seniority.

WHY MARKDOWN AND NOT DIRECT PUBLISHING
--------------------------------------
Substack has no stable public API for creating posts. Anything that claims to
automate it works by driving a browser session, which breaks often and can put
your account at risk. The reliable workflow is:

    Action runs Monday → commits digests/2026-09-21.md → you get a GitHub
    notification → you open it, read it, top and tail it with a paragraph of
    your own judgement, paste into Substack, publish.

That takes about five minutes and it is also what makes the newsletter worth
subscribing to. A raw automated dump of 80 links is a feed; your commentary on
which three postings actually matter this week is a publication.
"""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JOBS_JSON = ROOT / "data" / "jobs.json"
DIGEST_DIR = ROOT / "digests"

DAYS = 7

# Print order and human-readable names for our seniority buckets.
LEVEL_ORDER = [
    ("executive", "Director and above"),
    ("lead", "Head of unit / manager"),
    ("senior", "Senior"),
    ("mid", "Mid-level"),
    ("entry", "Entry level"),
    ("internship", "Internships and fellowships"),
    ("unclassified", "Other"),
]


def days_until(deadline: str | None) -> int | None:
    if not deadline:
        return None
    try:
        d = datetime.strptime(deadline, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        return None
    return (d - datetime.now(timezone.utc)).days


def main() -> int:
    if not JOBS_JSON.exists():
        print("No data/jobs.json yet — run scripts/fetch.py first.")
        return 1

    jobs = json.loads(JOBS_JSON.read_text(encoding="utf-8"))

    cutoff = (datetime.now(timezone.utc) - timedelta(days=DAYS)).strftime("%Y-%m-%d")

    def recently_added(job: dict) -> bool:
        """Same rule the web page uses.

        "We first saw it this week" is not quite the same as "it is new". On
        the very first run we see everything for the first time, so without
        the second test your opening newsletter would be a dump of every
        vacancy in the sector. We also require that the organisation posted it
        recently, wherever it tells us the posting date.
        """
        if (job.get("first_seen") or "") < cutoff:
            return False
        posted = job.get("date_posted")
        if posted and posted < (datetime.now(timezone.utc) - timedelta(days=14)).strftime("%Y-%m-%d"):
            return False
        return True

    new_jobs = [j for j in jobs if recently_added(j)]

    # Group by seniority level.
    by_level: dict[str, list[dict]] = defaultdict(list)
    for job in new_jobs:
        by_level[job.get("seniority") or "unclassified"].append(job)

    n_orgs = len({j.get('organisation') for j in new_jobs})
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    lines: list[str] = []

    lines.append(f"# New roles in development banks and international organisations")
    lines.append("")
    lines.append(f"*Week to {today}. {len(new_jobs)} new posting{'' if len(new_jobs) == 1 else 's'} "
                 f"across {n_orgs} organisation{'' if n_orgs == 1 else 's'}.*")
    lines.append("")
    lines.append("> Write your intro here: what's the pattern this week? Which one "
                 "posting would you tell a friend about? Delete this line before publishing.")
    lines.append("")

    for level_key, level_name in LEVEL_ORDER:
        group = by_level.get(level_key)
        if not group:
            continue

        # Within a level, put the most urgent deadlines first.
        group.sort(key=lambda j: j.get("deadline") or "9999-12-31")

        lines.append(f"## {level_name}")
        lines.append("")

        for job in group:
            place = ", ".join(filter(None, [job.get("city"), job.get("country")])) or "Location not stated"
            left = days_until(job.get("deadline"))

            if left is None:
                closing = "no deadline listed"
            elif left < 0:
                continue                     # already closed, don't publish it
            elif left <= 7:
                closing = f"**closes in {left} day{'' if left == 1 else 's'}**"
            else:
                closing = f"closes {job['deadline']}"

            lines.append(
                f"- [{job['title']}]({job['url']}) — {job.get('organisation', '')}. "
                f"{place}. {closing}."
            )

        lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("The full list, updated daily: https://YOUR-USERNAME.github.io/mdb-jobs/")
    lines.append("")

    DIGEST_DIR.mkdir(parents=True, exist_ok=True)
    out_path = DIGEST_DIR / f"{today}.md"
    out_path.write_text("\n".join(lines), encoding="utf-8")

    print(f"Wrote {out_path} — {len(new_jobs)} new jobs.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
