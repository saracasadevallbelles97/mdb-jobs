"""
normalise.py — turn messy source data into consistent, filterable values.

THE PROBLEM
-----------
You want to filter by seniority. But no two institutions describe it the same
way. The World Bank uses grades GA–GK. The UN uses P-1 to P-7, D-1, D-2, and
G/NO grades. The EBRD uses its own bands. ReliefWeb says "5-9 years
experience". Job titles say "Senior", "Lead", "Principal", "Head of".

If you filter on the raw text you get 200 distinct values and a useless
dropdown. So we map everything onto ONE small ladder of buckets.

WHY RULES BEFORE AI
-------------------
You said you want an "AI system". Here is the honest engineering answer:
for this specific job, a lookup table beats a language model. Grade codes are
a closed, published vocabulary — "P-5" means exactly one thing, always. A
rule gets it right 100% of the time, for free, in a millisecond, and you can
read the rule and see why it decided what it decided.

Save the language model for the genuinely fuzzy residue: a title like
"Country Manager, Sahel Regional Hub" with no grade attached. That is what
classify_with_llm() below is for, and it only ever runs on the leftovers.
"""

from __future__ import annotations

import re

# Our ladder, from junior to senior. Keep it SHORT — a filter with six
# options gets used; one with twenty does not.
SENIORITY_LEVELS = [
    "internship",
    "entry",        # 0–2 years, analyst, associate, JPO, young professional
    "mid",          # 3–7 years, officer, specialist
    "senior",       # 8–12 years, senior specialist, principal
    "lead",         # manager, head of unit, lead
    "executive",    # director, VP, chief
]

# ----------------------------------------------------------------------
# Rule 1: official grade codes. Highest confidence, so we check these first.
# ----------------------------------------------------------------------
GRADE_PATTERNS: list[tuple[str, str]] = [
    # UN common system professional grades
    (r"\bP[-\s]?1\b|\bP[-\s]?2\b", "entry"),
    (r"\bP[-\s]?3\b|\bP[-\s]?4\b", "mid"),
    (r"\bP[-\s]?5\b", "senior"),
    (r"\bP[-\s]?6\b|\bP[-\s]?7\b", "lead"),
    (r"\bD[-\s]?1\b|\bD[-\s]?2\b|\bASG\b|\bUSG\b", "executive"),
    # UN national officer and general service
    (r"\bNO[-\s]?[AB]\b|\bG[-\s]?[1-4]\b", "entry"),
    (r"\bNO[-\s]?[CD]\b|\bG[-\s]?[5-7]\b", "mid"),
    # World Bank Group grades
    (r"\bG[A-C]\b", "entry"),
    (r"\bG[DE]\b", "mid"),
    (r"\bG[FG]\b", "senior"),
    (r"\bGH\b", "lead"),
    (r"\bG[IJK]\b", "executive"),
    # ReliefWeb's free-text experience bands
    (r"0-2 years", "entry"),
    (r"3-4 years|5-9 years", "mid"),
    (r"10\+? years", "senior"),
]

# ----------------------------------------------------------------------
# Rule 2: words in the job title. Order matters — we check the most senior
# patterns first, because "Senior Director" should land on executive, not senior.
# ----------------------------------------------------------------------
TITLE_PATTERNS: list[tuple[str, str]] = [
    (r"\b(president|vice[- ]president|chief|managing director|executive director"
     r"|secretary[- ]general|director[- ]general)\b", "executive"),
    (r"\b(director|deputy director)\b", "executive"),
    (r"\b(head of|team lead|lead |manager|chief of (party|unit|section))\b", "lead"),
    (r"\b(principal|senior|sr\.?|expert)\b", "senior"),
    (r"\b(officer|specialist|advisor|adviser|economist|engineer|analyst)\b", "mid"),
    (r"\b(associate|assistant|junior|jr\.?|jpo|junior professional"
     r"|young professional|graduate|trainee)\b", "entry"),
    (r"\b(intern|internship|apprentice|fellow(ship)?)\b", "internship"),
]

CONSULTANCY_PATTERNS = r"\b(consultant|consultancy|short[- ]term|stc\b|sti\b|individual contractor|roster)\b"


def classify_seniority(job: dict) -> tuple[str | None, float]:
    """Return (level, confidence 0-1).

    We return a confidence score so that later you can choose to send only the
    low-confidence ones to a language model, and leave the rest alone.
    """
    title = (job.get("title") or "").lower()
    grade = (job.get("grade") or "").lower()
    haystack = f"{grade} {title}"

    # Internships override everything — a "Senior Management Internship" is
    # still an internship.
    if re.search(r"\b(intern|internship)\b", haystack):
        return "internship", 0.95

    # What each signal says on its own.
    grade_level = None
    for pattern, level in GRADE_PATTERNS:
        if re.search(pattern, grade, flags=re.IGNORECASE):
            grade_level = level
            break

    title_level = None
    for pattern, level in TITLE_PATTERNS:
        if re.search(pattern, title, flags=re.IGNORECASE):
            title_level = level
            break

    # WHEN THE TWO SIGNALS DISAGREE
    # -----------------------------
    # Normally the grade wins: it is the institution's own official vocabulary
    # and it means exactly one thing. Titles are marketing.
    #
    # The one exception is executive titles. "Director", "Vice-President" and
    # "Chief" are job-defining in this sector — nobody is called a Director
    # loosely — so those override a lower grade. Without this rule, a
    # "Director, Infrastructure" carrying a mid-range grade code lands in the
    # wrong bucket, and your Director-level subscribers stop trusting the filter.
    if title_level == "executive":
        return "executive", 0.85

    if grade_level:
        # Flag the disagreement by lowering confidence, so you can review
        # these later without having to re-run everything.
        confidence = 0.7 if (title_level and title_level != grade_level) else 0.9
        return grade_level, confidence

    if title_level:
        return title_level, 0.6

    return None, 0.0


def classify_contract(job: dict) -> str | None:
    """Staff post vs consultancy vs internship — a filter people actually want."""
    text = f"{job.get('title', '')} {job.get('contract_type', '')}".lower()

    if re.search(r"\b(intern|internship)\b", text):
        return "Internship"
    if re.search(CONSULTANCY_PATTERNS, text):
        return "Consultancy"
    if job.get("contract_type"):
        return job["contract_type"]
    return "Staff"


# ----------------------------------------------------------------------
# Tidy-up helpers
# ----------------------------------------------------------------------

COUNTRY_FIXES = {
    "usa": "United States",
    "us": "United States",
    "u.s.": "United States",
    "uk": "United Kingdom",
    "drc": "Democratic Republic of the Congo",
}


def clean_location(job: dict) -> dict:
    """Fix the small inconsistencies that break a dropdown filter."""
    for key in ("city", "country"):
        value = job.get(key)
        if not value:
            continue
        value = " ".join(str(value).split())        # collapse whitespace
        if key == "country":
            value = COUNTRY_FIXES.get(value.lower(), value)
        job[key] = value

    # "Remote" and "Home based" mean the same thing to a job seeker.
    if job.get("city") and re.search(r"home[- ]based|remote|telecommut",
                                     job["city"], flags=re.IGNORECASE):
        job["city"] = "Remote"

    return job


def normalise(job: dict) -> dict:
    """Run every rule over one job dictionary. Called once per job per run."""
    job = clean_location(job)

    level, confidence = classify_seniority(job)
    job["seniority"] = level or "unclassified"
    job["seniority_confidence"] = confidence

    job["contract_type"] = classify_contract(job)

    # Tidy the title: strip stray whitespace and trailing grade codes in
    # brackets, which make titles hard to scan.
    if job.get("title"):
        job["title"] = " ".join(job["title"].split())

    return job


# ----------------------------------------------------------------------
# OPTIONAL: the actual AI bit.
# ----------------------------------------------------------------------

def classify_with_llm(unclassified_jobs: list[dict], api_key: str) -> dict[str, str]:
    """Ask a language model to bucket the jobs the rules couldn't handle.

    Only call this on jobs where seniority == "unclassified". On a typical run
    that is a handful out of several hundred, which keeps the cost near zero.

    This function is deliberately left as a stub with the prompt written out.
    Get the rule-based pipeline running end to end FIRST. Add this later, when
    you can see from your own data how many jobs actually fall through.
    """
    if not unclassified_jobs or not api_key:
        return {}

    # Batch them into one request rather than one request per job — far
    # cheaper and faster.
    listing = "\n".join(
        f"{j['id']}: {j['title']} ({j.get('organisation', '')})"
        for j in unclassified_jobs[:100]
    )

    prompt = f"""Classify each job posting into exactly one seniority level.

Allowed levels: {", ".join(SENIORITY_LEVELS)}

Return ONLY a JSON object mapping each id to its level. No explanation,
no markdown fences.

Jobs:
{listing}
"""

    # Implementation left to you — see README, "Adding the AI step".
    # The shape you want back is: {"a1b2c3d4": "senior", ...}
    raise NotImplementedError(
        "Optional step. See README section 'Adding the AI step'.\n"
        f"Prompt is ready:\n{prompt[:200]}..."
    )
