# Design notes for the listing page

Recorded here so future-you knows why things look the way they do.

**Brief.** One long table that people scroll, grouped by organisation. No
filters, no dropdowns, no search — the request was explicitly for something
that reads like a spreadsheet and simply keeps growing. Every control removed
is one fewer thing between a reader and the list.

**What that changes.** With no filters, ordering carries all the weight. So:
organisations alphabetically, and inside each one, soonest closing date first.
The links across the top are anchors, not filters — they jump, and nothing ever
disappears from the page. That distinction matters: a filter that hides things
makes people wonder what they're missing; an anchor doesn't.

**The one bold element.** Closing dates. Everything in this sector runs on
application windows, so that's the column worth encoding visually: the days
remaining are emphasised, and turn amber under three weeks, red under one. Those
two colours appear nowhere else on the page, so they never lose their meaning.
Everything else stays deliberately quiet.

**Colour.** Cool institutional greys, a deep petrol ink, one teal accent for
links, and the two-step urgency scale reserved for deadlines.

- `#edf0ef` page, `#ffffff` rows, `#f6f8f7` stripe, `#1b2a2e` ink,
  `#5c6e70` secondary, `#cfd8d6` rules, `#0f5f6b` accent,
  `#a56a00` closing soon, `#9e2b25` closing now.

**Type.** Spectral for role titles and organisation names — a serif makes a long
list read as a listing rather than a database dump, and it separates the title
from its metadata without needing a size jump. Archivo for everything
functional: column headers, dates, counts. Dates use tabular figures so the
columns line up the way they would in a spreadsheet.

**Sticky headers.** Two levels: the column header row, and the organisation
banner beneath it. Both use `position: sticky` on the cells rather than the
rows, because a sticky `<tr>` is ignored by browsers. The banner's offset is
tied to the `--head-h` variable so the two can't drift apart.

**Narrow screens.** Six columns don't fit on a phone and squeezing them makes
all six unreadable. Grade and Posted are hidden below 760px; Role, Location and
Closes are what people actually scan for.

**Closed postings** are hidden rather than greyed out. They're still in
`data/jobs.json`, so nothing is lost, but there's no reason to make someone
scroll past something they can't apply to. A line under the table says how many.

**Empty and error states** say what happened and what to do about it. The
commonest failure is opening the file directly instead of serving it, so that
case names the exact command to run.
